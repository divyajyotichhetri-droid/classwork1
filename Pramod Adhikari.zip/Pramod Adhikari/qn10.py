'''
10. Countdown Timer Problem: Start from a given number 
and count down to 1, decreasing the number by 1 each time.
'''
num = int(input("Enter starting number: "))

while num >= 1:
    print(num)
    num -= 1