'''
3. Multiplication Table Printer Problem: Print the 
multiplication table for a given number up to 10, but 
skip the third iteration.
'''
num = int(input("Enter a number: "))

for i in range(1, 11):
    if i == 3:
        continue
    print(f"{num} x {i} = {num * i}")
