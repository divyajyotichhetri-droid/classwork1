'''
7. Validate Password Problem: Keep asking the user to enter
 a password until they enter "python123".
'''
while True:
    password = input("Enter password: ")

    if password == "python123":
        print("Access Granted")
        break
    else:
        print("Wrong Password")