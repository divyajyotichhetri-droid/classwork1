'''
1. Counting Negative Numbers Problem: 
Given a list of numbers, count how many are negative. 
numbers = [2, -3, 4, -5, -6, 7, 8, -9]
'''
numbers = [2, -3, 4, -5, -6, 7, 8, -9]

count = 0
for num in numbers:
    if num < 0:
        count += 1

print("Negative numbers:", count)