'''
4. Reverse a Number Problem: Reverse a given number using
 a loop.
'''
num = int(input("Enter a number: "))
reverse = 0

while num > 0:
    digit = num % 10
    reverse = reverse * 10 + digit
    num //= 10

print("Reversed number:", reverse)