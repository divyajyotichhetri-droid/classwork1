'''
5. Find the First Repeated Character Problem: Given a string,
 find the first character that appears more than once.
'''
text = input("Enter a string: ")
seen = set()

for ch in text:
    if ch in seen:
        print("First repeated character:", ch)
        break
    seen.add(ch)